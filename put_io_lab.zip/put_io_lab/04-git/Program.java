// class provides solution to concat string John and Doe 
public class Main {
  public static void main(String[] args) {
    String firstName = "John ";
    String lastName = "Smith";
    String fullName = firstName + lastName;
    System.out.println(fullName);  
  }
}
